package workshop1;

public class Test01 {

	public static void main(String[] args) {
//		System.out.println(args[0]);
//		System.out.println(args[1]);
		double numerator = Double.parseDouble(args[0]);
		double denominator = Double.parseDouble(args[1]);
		
		if ((numerator % denominator) <= 1) {
			System.out.println("나머지가 1보다 작거나 같다!");
		}
		else {
			System.out.println("나머지가 1보다 크다!");
		}
		
	}

}
