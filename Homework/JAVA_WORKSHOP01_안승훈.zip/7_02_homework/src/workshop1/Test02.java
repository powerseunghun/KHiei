package workshop1;

public class Test02 {

	public static void main(String[] args) {
		double arg = Double.parseDouble(args[0]);
		double sum = 0;
		double mul = 1;
		double avg = 0;
		if (!(arg >= 5 && arg <= 10)) {
			System.out.println("다시 입력하세요");
		}
		else {
			for(int i = 1; i <= arg; i++) {
				sum += i;
				mul *= i;
			}
			avg = sum / arg;
			System.out.println("합 : " + sum);
			System.out.println("곱 : " + mul);
			System.out.println("평균 : " + avg);
		}
	}
}
