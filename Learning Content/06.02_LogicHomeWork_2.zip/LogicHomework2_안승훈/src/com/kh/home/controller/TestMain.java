package com.kh.home.controller;

import com.kh.home.view.Menu;

public class TestMain {
	
	public static void main(String[] args) {
		Menu m = new Menu();
		m.mainMenu();
		
	}
}
